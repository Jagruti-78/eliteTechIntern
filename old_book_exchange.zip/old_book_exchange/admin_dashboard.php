<?php
$conn = mysqli_connect("localhost", "root", "", "old_book_exchange");

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // match the inserted hash method

    $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Success - redirect to dashboard
        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid Credentials');</script>";
    }
}
?>
