<?php
include('db.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // You can replace this with DB validation if needed
    if ($username === "admin" && $password === "admin123") {
        // Redirect to phpMyAdmin
        header("Location: http://localhost/phpmyadmin/");
        exit();
    } else {
        echo "<script>alert('Invalid Credentials');</script>";
    }
}
?>

